import axios from 'axios';
const API_URL = 'https://apis.vnvision.in/api/';

export const IMAGE_URL = 'https://apis.vnvision.in/';

export const fetchSliders = () => axios.get(`${API_URL}if/sliders`);
export const fetchCompanies = () => axios.get(`${API_URL}if/companies`);
export const fetchServiceSliders = () => axios.get(`${API_URL}if/service-sliders`);
export const fetchTestimonials = () => axios.get(`${API_URL}if/testimonials`);
export const fetchCards = () => axios.get(`${API_URL}if/Cards`);
export const fetchservice = () => axios.get(`${API_URL}if/services`);
export const fetchPortfolioItems = () => axios.get(`${API_URL}if/portfolio`);
export const fetchPortfolio = () => axios.get(`${API_URL}portfolio`);
export const fetchMissionVision = () => axios.get(`${API_URL}if/ifMissionvision`);
export const fetchLagacyofExcellence = () => axios.get(`${API_URL}if/LagacyofExcellence`);

export const fetchprivacy = ()=> axios.get(`${API_URL}privacy`);

export const fetchNewsServices = () => axios.get(`${API_URL}if/newsservices`);
export const fetchTeamData = () => axios.get(`${API_URL}if/team`); 
export const fetchKnowMore = () => axios.get(`${API_URL}if/knowmore`);
export const fetchService = () => axios.get(`${API_URL}if/services`);
export const fetchcontact2 = () => axios.get(`${API_URL}if/contact2`);

export const createContactus = (data) => axios.post(`${API_URL}if/contactus`, data);
export const subscribeNewsletter = (email) => axios.post(`${API_URL}if/newsletter`, { email });
export const fetchCompaniesData = () => axios.get(`${API_URL}if/ourgroup`);
export const fetchSocialLinks = () => axios.get(`${API_URL}footers`);

export const fetchServiceHero = () => axios.get(`${API_URL}if/service-hero`);
export const fetchServiceSupport = () => axios.get(`${API_URL}if/servicesupport`);
export const fetchServiceGoals = () => axios.get(`${API_URL}if/ifserviceGoals`);
export const fetchServiceInnovation = () => axios.get(`${API_URL}if/service-technology-and-innovation`);


