import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Home from "./components/home/Home";
import Services from "./components/Services/Services";
import Portfolio from "./components/Portfolio/Portfolio";
import ProjectDetail from './components/Portfolio/ProjectDetail';
import AboutUs from "./components/About-Us/AboutUs";
import Navbar from "./components/Navbar";
import ContactUs from "./components/ContactUs/ContactUs";
import News from "./components/News/News";
import NewsDetail from "./components/News/NewsDetail";
import Footer from "./components/Footer";
import TermsAndConditions from './components/Terms&Conditions/Termsandconditions';
import PrivacyPolicy from './components/PrivacyPolicy/PrivacyPolicy';
import './App.css';
import 'font-awesome/css/font-awesome.min.css';

function App() {
  const [language, setLanguage] = useState("en");

  // Load saved language from localStorage when the app mounts
  useEffect(() => {
    const savedLanguage = localStorage.getItem("selectedLanguage");
    if (savedLanguage) {
      setLanguage(savedLanguage); // Set the saved language
    }
  }, []);

  // Handle language change and save it to localStorage
  const handleLanguageChange = (lang) => {
    setLanguage(lang); // Update the state
    localStorage.setItem("selectedLanguage", lang); // Save language to localStorage
  };

  // Scroll to top on route change
  const ScrollToTop = () => {
    const location = useLocation();
    useEffect(() => {
      window.scrollTo(0, 0); // Scroll to top
    }, [location]);

    return null;
  };

  return (
    <BrowserRouter>
      <Navbar handleLanguageChange={handleLanguageChange} language={language} />
      <ScrollToTop /> {/* This ensures scrolling to the top on route change */}
      <Routes>
        <Route path="/" element={<Home language={language} />} />
        <Route path="/home" element={<Home language={language} />} />
        <Route path="/services" element={<Services language={language} />} />
        <Route path="/portfolio" element={<Portfolio language={language} />} />
        <Route path="/aboutus" element={<AboutUs language={language} />} />
        <Route path="/contact-us" element={<ContactUs language={language} />} />
        <Route path="/news" element={<News language={language} />} />
        <Route path="/terms-and-conditions" element={<TermsAndConditions language={language} />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy language={language} />} />
        <Route path="/news/:id" element={<NewsDetail language={language} />} />
        <Route path="/project-detail" element={<ProjectDetail language={language} />} />
      </Routes>
      <Footer language={language} />
    </BrowserRouter>
  );
}

export default App;