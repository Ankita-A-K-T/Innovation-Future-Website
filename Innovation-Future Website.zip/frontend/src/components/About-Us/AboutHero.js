import React, { useEffect, useState } from 'react';
import { fetchPortfolioItems, IMAGE_URL } from '../../API/api';

function AboutHero({ language }) {
  const [aboutData, setAboutData] = useState(null);
  const [error, setError] = useState(null);
  const id = '67384af0ac235c6be31c5ea9'; // ID for filtering

  useEffect(() => {
    const fetchAboutData = async () => {
      try {
        const response = await fetchPortfolioItems(); // Axios already returns data
        const data = response.data; // Access data from Axios response

        // Find the about item with the matching ID
        const aboutItem = data.find((item) => item._id === id);
        setAboutData(aboutItem);
      } catch (err) {
        setError(err.message); // Handle errors
      }
    };

    fetchAboutData();
  }, [id]);

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!aboutData) {
    return <div>Loading...</div>;
  }

  const { title, image } = aboutData;
  const imageUrl = `${IMAGE_URL}${image}`; // Construct full image URL

  return (
    <div className="position-relative" dir={language === 'en' ? 'ltr' : 'rtl'}>
      <img
        className="d-block w-100 carousel-image"
        src={imageUrl}
        alt={title}
      />
      <div
        className="position-absolute bottom-0 text-light"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          width: '100%',
          padding: '10px',
        }}
      >
        <h1 className="heroabout" >
          {language === 'en' ? 'About us' : 'من نحن'}
        </h1>
      </div>
    </div>
  );
}

export default AboutHero;
