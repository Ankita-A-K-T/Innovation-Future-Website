import React from 'react';
import AboutUsBody from './AboutUsBody';
import AboutHero from './AboutHero';
import AboutUsInnovation from './AboutUsInnovation';
import OurTeam from './OurTeam';

function AboutUs({language}) {
    return ( 
        <>
        <AboutHero language={language}/>
       <AboutUsBody language={language}/>
       <AboutUsInnovation language={language}/>
       <OurTeam language={language}/>
        </>
     );
}

export default AboutUs;