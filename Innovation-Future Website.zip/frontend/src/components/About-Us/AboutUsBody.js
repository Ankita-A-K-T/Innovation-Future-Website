import React, { useEffect, useState } from "react";
import { fetchKnowMore, fetchMissionVision, IMAGE_URL } from "../../API/api"; // Import from api.js
import "./AboutUs.css";

function AboutUsBody({ language }) {
  const [knowMoreData, setKnowMoreData] = useState([]);
  const [missionVisionData, setMissionVisionData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch "Know More" Data
  useEffect(() => {
    const getKnowMoreData = async () => {
      try {
        const response = await fetchKnowMore();
        setKnowMoreData(response.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    getKnowMoreData();
  }, []);

  // Fetch "Mission & Vision" Data
  useEffect(() => {
    const getMissionVisionData = async () => {
      try {
        const response = await fetchMissionVision();
        setMissionVisionData(response.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    getMissionVisionData();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error fetching data: {error}</div>;

  return (
    <div className="container-fluid pb-3" dir={language === "en" ? "ltr" : "rtl"}>
      {/* "Know More" Section */}
      {knowMoreData.map((item) => (
        <div key={item._id} className="row p-5 pb-0">
          <h2 className="mb-4 AboutUstitle">
            {item.mainTitle?.[language] || "Default Title"}
          </h2>

          <div className="col-md-7">
            <div className="AboutUstext">
              {item.paragraphs.map((paragraph) => (
                <div
                  key={paragraph._id}
                  dangerouslySetInnerHTML={{
                    __html: paragraph?.[language] || "Default text",
                  }}
                />
              ))}
            </div>
          </div>

          <div className="col-md-5">
            <div className="innovation-image">
              <img
                 src="./image/about1-img.jpeg"
                alt="Business handshake"
                className="img-fluid"
                style={{ borderLeft: "4px solid #00C165" }}
              />
            </div>
          </div>
        </div>
      ))}

      {/* "Mission & Vision" Section */}
      <div className="container-fluid p-4 pb-5"  dir={language === "en" ? "ltr" : "rtl"}>
       <div
  dir={language === "en" ? "ltr" : "rtl"}
  className="row mvcontener company-mission-vision ps-5 pt-0"
  style={{
    background: "#002752",
    color: "white",
    paddingRight: language === "ar" ? "25px" : "0px", // Conditional padding for Arabic
  }}
>
          <h2 className="pt-4 ps-0 p-4">
            {language === "en"
              ? "Company Mission & Vision"
              : "الرؤية والرسالة "}
          </h2>

          <div className="mission-vision-container d-flex justify-content-between">
            <div className="d-flex flex-column">
              {/* Mission Card */}
              <div className="mission-card d-flex align-items-center mb-4"  dir={language === "en" ? "ltr" : "rtl"}>
                <div className="mcc">
                  <img
                    src={`${IMAGE_URL}/uploads/${missionVisionData[0]?.image}`}
                    alt="Mission"
                    className="img-fluid imgm"
                  />
                </div>
                <div className="ps-5 pe-5">
                  <h3 className="miss">
                    {language === "en" ? "OUR MISSION" : "رسالتنا"}
                  </h3>
                  <p className="missionpara">
                    {missionVisionData[0]?.title?.[language] || "Default Mission"}
                  </p>
                </div>
              </div>

              {/* Vision Card */}
              <div className="vision-card d-flex align-items-center pb-5"  dir={language === "en" ? "ltr" : "rtl"}>
                <div className="mvv">
                  <img
                 
                    src={`${IMAGE_URL}/uploads/${missionVisionData[0]?.image2}`}
                    alt="Vision"
                    className="img-fluid imgv"
                  />
                </div>
                <div className="ps-5 pe-5">
                  <h3 className="visi">
                    {language === "en" ? "OUR VISION" : "رؤيتنا"}
                  </h3>
                  <p className="missionpara">
                    {missionVisionData[0]?.description?.[language] || "Default Vision"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AboutUsBody;
