import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom"; // Import the useNavigate hook
import "../home/InnovationFuture.css";
import { IMAGE_URL, fetchLagacyofExcellence } from "../../API/api"; // Import the centralized API function

function AboutUsInnovation({ language }) {
  const navigate = useNavigate(); // Initialize the navigate function

  // State variables to hold the fetched data
  const [experience, setExperience] = useState(null);
  const [industries, setIndustries] = useState(null);
  const [projects, setProjects] = useState(null);

  // Fetch data from the API on component mount
  useEffect(() => {
    const fetchLegacyData = async () => {
      try {
        // Use the centralized API function
        const response = await fetchLagacyofExcellence();
        const data = response.data;

        // Set the state variables with the fetched data
        if (data?.data?.length > 0) {
          setExperience(data.data[0].expreience);
          setIndustries(data.data[0].industries);
          setProjects(data.data[0].projects);
        }
      } catch (error) {
        console.error("Error fetching legacy data:", error);
      }
    };

    fetchLegacyData();
  }, []);

  const handleExploreMore = () => {
    navigate("/aboutUs"); // Redirect to the About Us page
  };

  return (
    <div className="container-fluid text-white align-items-center text-center pb-5 inovation-container">
      <h3 className="p-5 Innovation-para">
        {language === "en"
          ? "Innovation Future By Numbers A Legacy of Excellence"
          : "مستقبل الابتكار بالأرقام: إرث من التميز"}
      </h3>

      <div
        className="row d-flex justify-content-between align-items-center text-center pt-5"
        style={{ gap: "20px" }}
      >
        <div
          className="d-flex justify-content-between align-items-center innovation-row"
          style={{ width: "100%" }}
        >
          <div style={{ flex: 1 }}>
            <img
              src="./image/inovation-img1.png"
              className="vision-image"
              alt=""
            />
            <h6 className="innovationh6 pt-4">
              {language === "en"
                ? `OVER ${experience}`
                : `أكثر من ${experience}`}
            </h6>
            <h5 className="innovationh5 pt-3">
              {language === "en" ? "Years Of Expertise" : "سنوات من الخبرة"}
            </h5>
          </div>

          {/* Vertical Line 1 */}
          <div className="vertical-line"></div>

          <div style={{ flex: 1 }}>
            <img
              src="./image/inovation-img2.png"
              className="vision-image"
              alt=""
            />
            <h6 className="innovationh6 pt-4">
              {language === "en"
                ? `MORE THAN ${industries}`
                : `أكثر من ${industries}`}
            </h6>
            <h5 className="innovationh5 pt-3">
              {language === "en" ? "Industries Covered" : "الصناعات المغطاة"}
            </h5>
          </div>

          {/* Vertical Line 2 */}
          <div className="vertical-line" id="innovation"></div>

          <div style={{ flex: 1 }}>
            <img
              src="./image/inovation-img3.png"
              className="vision-image"
              alt=""
            />
            <h6 className="innovationh6 pt-4">
              {language === "en" ? `${projects}+` : `${projects}+`}
            </h6>
            <h5 className="innovationh5 pt-3">
              {language === "en" ? "Successful Projects" : "مشاريع ناجحة"}
            </h5>
          </div>
        </div>
      </div>

      <p className="p-3 innovationhp">
        {language === "en"
          ? "Since our inception, Innovation Future has been dedicated to delivering top-quality, secure, and adaptable digital solutions that satisfy the needs of today and unlock the opportunities of tomorrow."
          : "منذ تأسيسنا ، كرس مستقبل الابتكار جهوده لتقديم حلول رقمية عالية الجودة وآمنة وقابلة للتكيف تلبي احتياجات اليوم وتطلق العنان لفرص الغد."}
      </p>
    </div>
  );
}

export default AboutUsInnovation;
