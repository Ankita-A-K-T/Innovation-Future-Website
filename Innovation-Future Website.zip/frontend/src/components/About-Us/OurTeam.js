import React, { useState, useEffect } from 'react';
import './OurTeam.css';
import { FaLinkedin } from 'react-icons/fa';
import { fetchTeamData } from '../../API/api'; // Adjust the import path as necessary
import { IMAGE_URL } from '../../API/api'; // Ensure you have this constant to point to your image base URL

const OurTeam = ({ language }) => {
  const [teamMembers, setTeamMembers] = useState([]);

  useEffect(() => {
    const getTeamData = async () => {
      try {
        const response = await fetchTeamData();
        setTeamMembers(response.data);
      } catch (error) {
        console.error('Error fetching team data:', error);
      }
    };
    getTeamData();
  }, []);

  return (
    <div className="team-container" dir={language === "en" ? "ltr" : "rtl"}>
      <div className="row justify-content-center teamm">
        {teamMembers.length > 0 ? (
          teamMembers.map((member, index) => (
            <div className="col-md-2 team-card mb-4 mx-2" key={member._id || index}>
              <div className="team-image-container">
                <div className="team-image-wrapper">
                  <img
                    src={`${IMAGE_URL}${member.image}`}
                    alt={member.name.en}
                    className="team-image"
                  />
                </div>
              </div>
              <h5 className="team-name">{member.name?.[language] || member.name.en}</h5>
              <p className="team-description">{member.position?.[language] || member.position.en}</p>
              <a
                href={member.socialMedia}
                target="_blank"
                rel="noopener noreferrer"
                className="linkedin-link"
              >
                <FaLinkedin className="linkedin-icon" size={24} />
              </a>
            </div>
          ))
        ) : (
          <p>Loading team members...</p>
        )}
      </div>
    </div>
  );
};

export default OurTeam;
