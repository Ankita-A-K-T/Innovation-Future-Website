import React, { useState,useEffect } from 'react';
import './ContactUs.css';
import ContactUsHeader from './ContactUsHeader';
import { createContactus ,fetchcontact2, IMAGE_URL } from '../../API/api';


const countryCodes = [
    { code: "+91" },
    { code: "+1"},
    { code: "+44" },
    { code: "+61" },
    { code: "+971" },
    { code: "+966" },
    { code: "+81" },
    { code: "+49" },
    { code: "+33" },
    { code: "+55" },
    { code: "+86" },
    { code: "+7"},
    { code: "+82" },
    { code: "+39" },
    { code: "+34"},
    { code: "+63" },
    { code: "+65"},
    { code: "+27"},
    { code: "+92" },
    { code: "+880" },
    { code: "+20" },
    { code: "+66" },
    { code: "+60" },
    { code: "+52" },
    { code: "+46" },
    { code: "+41" },
    { code: "+31"},
    { code: "+32" },
    { code: "+48" },
    { code: "+353" },
    { code: "+47" },
    { code: "+90" },
    { code: "+43" },
    { code: "+351" },
    { code: "+372"},
    { code: "+380" },
    { code: "+58" },
    
];

function ContactUs({language}) {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        message: '',
        countryCode: '+966', // Default country code
    });
    
    const [contactInfo, setContactInfo] = useState(null);


    const [errors, setErrors] = useState({});

useEffect(() => {
    const fetchContactInfo = async () => {
        try {
            const response = await fetchcontact2();
            const data = await response.data;
            if (data && data.length > 0) {
                setContactInfo(data[0]); // Using the first entry from the API response
            }
        } catch (error) {
            console.error('Error fetching contact info:', error);
        }
    };

    fetchContactInfo();
}, []);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData({ ...formData, [id]: value });
    };

    const handleDropdownChange = (e) => {
        setFormData({ ...formData, countryCode: e.target.value });
    };

    const validateForm = () => {
        const formErrors = {};
        let isValid = true;

        if (!formData.firstName) {
            formErrors.firstName = 'First name is required';
            isValid = false;
        }
        if (!formData.lastName) {
            formErrors.lastName = 'Last name is required';
            isValid = false;
        }
        if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
            formErrors.email = 'Valid email is required';
            isValid = false;
        }
        if (formData.phone && !/^\+?[0-9]{10,15}$/.test(formData.phone)) {
            formErrors.phone = 'Phone number is invalid';
            isValid = false;
        }
        if (!formData.message) {
            formErrors.message = 'Message is required';
            isValid = false;
        }

        setErrors(formErrors);
        return isValid;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (validateForm()) {
            const contactData = {
                name: `${formData.firstName} ${formData.lastName}`,
                email: formData.email,
                phone:` ${formData.countryCode} ${formData.phone}`,
                message: formData.message,
            };

            try {
                const response = await createContactus(contactData);
                if (response.status === 201) {
                    alert('Message sent successfully!');
                    setFormData({ firstName: '', lastName: '', email: '', phone: '', message: '', countryCode: '+1' });
                } else {
                    alert('Something went wrong. Please try again later.');
                }
            } catch (error) {
                console.error('Error submitting the form:', error);
                alert('Error sending message.');
            }
        }
    };

    return (
        <>
            <ContactUsHeader language={language} />
            <div className="container-fluid p-5 fullscreen" style={{ backgroundColor: '#0B1A40' }}>
                <div className="row mt-5">
                    <div className="col-md-8 " dir={language === "en" ? "ltr" : "rtl"}>
                        <div dir={language === "en" ? "ltr" : "rtl"} className="contact contactmargin"  >
                           <h2 dir={language === "en" ? "ltr" : "rtl"} className="hight2"style={{ color: 'white' }}  >
    {language === "en" ? "Get In Touch With Us Today!" : "تواصل معنا  "}
</h2>

                            <form className="con" onSubmit={handleSubmit}  dir={language === "en" ? "ltr" : "rtl"} >
                                <div className="form-row d-flex flex-wrap mb-4 contactd ">
                                    <div className="form-group col-md-5 mb-3">
                                        <label htmlFor="firstName" className="name"> {language === "en" ? <>First Name</> : <>الاسم الاول </>}</label>
                                        <input
                                            type="text"
                                            className="form-control box"
                                            id="firstName"
                                             placeholder={language === "en" ? "John" : "جون"}
                                            style={{ padding: '10px',color:'white',backgroundColor:'#0B1A40' }}
                                            value={formData.firstName}
                                            onChange={handleChange}
                                        />
                                        {errors.firstName && <small className="text-danger">{errors.firstName}</small>}
                                    </div>
                                    <div className="form-group col-md-5 mb-3">
                                        <label htmlFor="lastName" className="name"> {language === "en" ? <>Last Name</> : <>اسم العائلة </>}</label>
                                        <input
                                            type="text"
                                            className="form-control box"
                                            id="lastName"
                                             placeholder={language === "en" ? "Doe" : "ظبية"}
                                            style={{ padding: '10px',color:'white',backgroundColor:'#0B1A40' }}
                                            value={formData.lastName}
                                            onChange={handleChange}
                                        />
                                        {errors.lastName && <small className="text-danger">{errors.lastName}</small>}
                                    </div>
                                </div>
                                <div className="form-row d-flex flex-wrap mb-4 contactd">
                                    <div className="form-group col-md-5 mb-3">
                                        <label htmlFor="email" className="name"> {language === "en" ? <>Email Address</> : <> البريد الالكتروني</>}</label>
                                        <input
                                            type="email"
                                            className="form-control box"
                                            id="email"
                                           placeholder={language === "en" ? "yourname@example.com" : "اسمك@example.com"}
                                            style={{ padding: '10px',color:'white',backgroundColor:'#0B1A40' }}
                                            value={formData.email}
                                            onChange={handleChange}
                                        />
                                        {errors.email && <small className="text-danger">{errors.email}</small>}
                                    </div>
                                    <div className="form-group col-md-5 mb-3">
                                        <label htmlFor="phone" className="name"> {language === "en" ? <>Phone (Optional)</> : <>رقم الهاتف (اختياري) </>}</label>
                                        <div className="d-flex">
                                            <select
                                                className="form-control box"
                                                id="countryCode"
                                                value={formData.countryCode}
                                                onChange={handleDropdownChange}
                                                style={{ padding: '10px', width: '30%',color:'white',backgroundColor:'#0B1A40' }}
                                            >
                                                {countryCodes.map((code, index) => (
                                                    <option key={index} value={code.code}>
                                                        {code.code} 
                                                    </option>
                                                ))}
                                            </select>
                                            <input
                                                type="text"
                                                className="form-control box"
                                                id="phone"
                                                 placeholder={language === "en" ? "Enter your phone number" : " رقم الهاتف  "}
                                                style={{ padding: '10px', width: '52%',color:'white',backgroundColor:'#0B1A40' }}
                                                value={formData.phone}
                                                onChange={handleChange}
                                            />
                                        </div>
                                        {errors.phone && <small className="text-danger">{errors.phone}</small>}
                                    </div>
                                </div>
                                <div className="form-row mb-4">
                                    <div className="form-group col-12">
                                        <label htmlFor="message" className="name"> {language === "en" ? <>Message</> : <>رسالة</>}</label>
                                        <textarea
                                            className="form-control box2"
                                            id="message"
                                           placeholder={language === "en" ? "Leave your message here..." : "  اترك رسالتك هنا"}
                                            rows="5"
                                           
                                            value={formData.message}
                                            onChange={handleChange}
                                        ></textarea>
                                        {errors.message && <small className="text-danger">{errors.message}</small>}
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start">
                                    <button type="submit" className="btn btn-dark cbutton">
                                       {language === "en" ? <>Submit </> : <>ارسال </>}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    {/* Information Section */}{/* Informa{/* Information Section */}
<div className="col-lg-3 col-md-6 col-sm-12 d-flex " dir={language === "en" ? "ltr" : "rtl"}>
  <div className="contactInfo">
    {/* Location Information */}
    <div className="mb-4">
      <div className="d-flex align-items-center">
        <img
            src="./image/contact1.png"
          alt="Location Icon"
          style={{ width: '50px', height: '50px', marginRight: '15px' }}
        />
        <div>
          <h5 className="text-white">{language === "en" ? "Innovation Future" : " مستقبل الابتكار"}</h5>
          <p style={{ fontFamily: 'Cairo', color: '#8EABE5', marginBottom: '5px' }}>
            {contactInfo?.Address?.[language] || "Address not found"}
          </p>
          <a 
            href={contactInfo?.maplink} 
            style={{ textDecoration: 'none' }} 
            target="_blank" 
            rel="noopener noreferrer"
          >
            {language === "en" ? "Google Maps link" : " رابط الموقع  "}
          </a>
        </div>
      </div>
    </div>
    <hr style={{ border: '3px solid #00C165', margin: '30px 0', width: '270px' }} />
    
    {/* Call Us Information */}
    <div className="mb-4">
      <div className="d-flex align-items-center">
        <img
           src="./image/contact2.png"
          alt="Call Us"
          style={{ width: '50px', height: '50px', marginRight: '15px' }}
        />
        <div>
          <h5 className="text-white">{language === "en" ? "Call Us" : " تواصل معنا "}</h5>
          <h6 className="card-text" dir="ltr" style={{ fontFamily: 'Cairo', color: '#8EABE5' }}>
            {contactInfo?.mobile1}
          </h6>
          <h6 className="card-text" dir="ltr" style={{ fontFamily: 'Cairo', color: '#8EABE5' }}>
            {contactInfo?.mobile2}
          </h6>
        </div>
      </div>
    </div>
    <hr style={{ border: '3px solid #00C165', margin: '30px 0', width: '270px' }} />

    {/* Reach Us Information */}
    <div className="mb-4">
      <div className="d-flex align-items-center">
        <img
           src="./image/contact3.png"
          alt="Reach Us"
          style={{ width: '50px', height: '50px', marginRight: '15px' }}
        />
        <div>
          <h5 className="text-white">{language === "en" ? "Reach Us" : "الوصول الينا "}</h5>
          <h6 className="card-text" dir="ltr" style={{ fontFamily: 'Cairo', color: '#8EABE5' }}>
            {contactInfo?.email}
          </h6>
        </div>
      </div>
    </div>
  </div>
</div>

                </div>
            </div>
             {/* Google Maps Embed */}
            <div className="container d-flex justify-content-center my-5">
                <iframe
                    className="map"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7242.671852915162!2d46.636398745795475!3d24.818183111827437!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee40eefcb6a9d%3A0xbc4308498520f827!2sAnas%20Ibn%20Malik%20Rd%2C%20Riyadh%20Saudi%20Arabia!5e0!3m2!1sen!2sin!4v1731161730419!5m2!1sen!2sin"
                    referrerPolicy="no-referrer-when-downgrade"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                ></iframe>
            </div>
            
        </>
    );
}

export default ContactUs; 