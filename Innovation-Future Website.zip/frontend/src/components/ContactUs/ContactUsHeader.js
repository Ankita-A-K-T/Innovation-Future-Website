import React, { useState, useEffect } from 'react';
import {fetchcontact2, IMAGE_URL } from '../../API/api';
function ContactUsHeader({ language }) {
    const [contactData, setContactData] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Fetch contact data from the API
       const fetchContactData = async () => {
    try {
        const response = await fetchcontact2(); // API function
        const data = response.data; // Axios response contains data directly

        // If data is available, set the first element
        if (data && data.length > 0) {
            setContactData(data[0]);
        }
    } catch (err) {
        setError(err.message); // Handle any errors
    }
};


        fetchContactData();
    }, []);

    // Handle errors
    if (error) {
        return <div>Error: {error}</div>;
    }

    // Handle loading state
    if (!contactData) {
        return <div>Loading...</div>;
    }

    // Extract image URL from the data
    const imageUrl = contactData.image ? `${IMAGE_URL}${contactData.image}` : '';

    return (
        <>
            {/* Hero Section */}
            <div
                className="contactimg"
                style={{
                    backgroundImage: imageUrl ? `url(${imageUrl})` : "url('/default-image.jpg')", // Fallback to default image if not found
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    height: '100vh',
                }}
            >
                {/* Adjusted the opacity to reduce the shading */}
                <div
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.50)',
                        zIndex: 1,
                    }}
                />
                <div style={{ position: 'relative', zIndex: 2 }}>
                    <h1 style={{ fontSize: '4rem', lineHeight: '1.2', color: '#fff' }}> {language === "en" ? "Contact Us" : "تواصل معنا"}</h1>
                </div>
            </div>
        </>
    );
}

export default ContactUsHeader;
