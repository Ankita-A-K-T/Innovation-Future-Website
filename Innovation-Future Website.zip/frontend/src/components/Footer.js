import React from 'react';
import { Link } from 'react-router-dom';
import './footer.css';
import { fetchSocialLinks } from '../API/api';

function Footer({ language }) {
  return (
    <>
      {/* Vertical Divider Above Footer */}
      <hr
        style={{
          borderTop: "3px solid #000",
          width: "100%",
          margin: "0 auto 30px auto",
        }}
      />

      <section className="container-fluid">
        <div className="row p-5">
          {/* Logo and Text Section */}
          <div className="col-md-6 col-12 pb-5 text-center text-md-start">
            <img className="navimg2 mb-3" src="/image/logo 1.png" alt="Logo" />
            <p className="footerpara" style={{ color: '#002753' }}>
              {language === "en"
                ? "Stay connected with us on social media and subscribe to our newsletter for the latest updates."
                : "ابقى على تواصل معنا من خلال قنوات التواصل الاجتماعي "}
            </p>
          </div>

          {/* Links and Social Media Section */}
          <div className="col-md-6 col-12 p-3 text-center text-md-start">
            <div className="ps-md-5 mb-4 footercontent">
              {/* Navigation Links */}
              <Link to="/contact-us" style={{ marginRight: '15px', textDecoration: 'none', color: '#002753' }}>
                {language === "en" ? "Contact Us" : "تواصل معنا "}
              </Link>
              <Link to="/news" style={{ marginRight: '15px', textDecoration: 'none', color: '#002753' }}>
                {language === "en" ? "News" : "الأخبار"}
              </Link>
              <Link to="/terms-and-conditions" style={{ marginRight: '15px', textDecoration: 'none', color: '#002753' }}>
                {language === "en" ? "Terms & Conditions" : "الشروط والأحكام "}
              </Link>
              <Link to="/privacy-policy" style={{ marginRight: '15px',textDecoration: 'none', color: '#002753' }}>
                {language === "en" ? "Privacy Policy" : "سياسة الخصوصية "}
              </Link>
            </div>

            {/* Social Media Icons */}
            <div className="social-media-container d-flex">
              {[
                { icon:  "icons8-whatsapp-94 1.png", url: "https://www.whatsapp.com"},
                { icon:  "icons8-twitter-logo-94 1.png", url: "https://x.com/Innfuturee?t=391AM8Ks4JuM7KdvB2mBgg&s=09" },
                { icon: "icons8-linkedin-94 1.png", url: "https://www.linkedin.com/company/innovation-future/" },
                { icon:  "icons8-instagram-94 1.png", url: "https://www.instagram.com/innfuturee?igsh=c254aDBqZ3RvdThi" },
              ].map((social, index) => (
                <div key={index} style={{ borderRadius: "50%", padding: "10px" }}>
                  <a href={social.url} target="_blank" rel="noopener noreferrer">
                    <img
                      src={`image/${social.icon}`}
                      alt={social.icon}
                      style={{ width: "50px", height: "50px" }}
                    />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Footer;