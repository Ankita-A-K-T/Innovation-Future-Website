import React, { useEffect, useState, useRef } from 'react';
import { NavLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import './Navbar.css';

function Navbar({ handleLanguageChange }) {
    const { t, i18n } = useTranslation();
    const [language, setLanguage] = useState(localStorage.getItem("selectedLanguage") || "en");
    const navCollapseRef = useRef(null);

    // Set language in i18n and state on load
    useEffect(() => {
        i18n.changeLanguage(language); // Sync i18n with stored language
        handleLanguageChange(language); // Notify parent of initial language
    }, [language, i18n, handleLanguageChange]);

    const changeLanguage = (lng) => {
        setLanguage(lng); // Update local state
        localStorage.setItem("selectedLanguage", lng); // Save to localStorage
        i18n.changeLanguage(lng); // Update i18n language
    };

    const closeNavbar = () => {
        if (navCollapseRef.current?.classList.contains('show')) {
            navCollapseRef.current.classList.remove('show');
        }
    };

    const menuItems = language === 'ar'
        ? ['services', 'aboutUs', 'portfolio', 'home']
        : ['home', 'portfolio', 'aboutUs', 'services'];

    return (
        <nav className="navbar navbar-expand-lg">
            <div className="container">
                <NavLink className="navbar-brand" to="/" style={{ width: '40%' }}>
                    <img
                        className='navimg1'
                       src="/image/Navbar-img1.png"
                        style={{ width: "45%" }}
                        alt="Logo"
                    />
                </NavLink>
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav" ref={navCollapseRef}>
                    <ul className="navbar-nav justify-content-end flex-grow-1 p-5">
                        {menuItems.map((item) => (
                            <li className="nav-item" key={item}>
                                <NavLink
                                    className="nav-link"
                                    to={`/${item}`}
                                    style={({ isActive }) => ({
                                        color: isActive ? '#00FFCC' : 'white'
                                    })}
                                    onClick={closeNavbar}
                                >
                                    {t(item)} {/* Translate each item */}
                                </NavLink>
                            </li>
                        ))}
                    </ul>

                    {/* Language Dropdown */}
                    <div className="dropdown">
                        <button
                            className="btn btn-secondary dropdown-toggle"
                            type="button"
                            id="dropdownLanguage"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            aria-label={language === 'en' ? 'Language: English' : 'Language: Arabic'}
                        >
                            {language === 'en' ? 'English' : 'Arabic'}
                        </button>
                        <ul className="dropdown-menu" aria-labelledby="dropdownLanguage">
                            <li>
                                <button
                                    className="dropdown-item"
                                    onClick={() => changeLanguage('en')}
                                >
                                    English
                                </button>
                            </li>
                            <li>
                                <button
                                    className="dropdown-item"
                                    onClick={() => changeLanguage('ar')}
                                >
                                    Arabic
                                </button>
                            </li>
                        </ul>
                    </div>

                    <a href="https://ifgame.vnvision.in/" rel="noopener noreferrer">
                        <img
                            className="navimg ms-3"
                            src="/image/Navbar-img2.png"
                            alt="Secondary Logo"
                            style={{ width: '70px', height: '30px' }}
                        />
                    </a>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;