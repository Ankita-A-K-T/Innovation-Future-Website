// src/components/News.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./News.css";
import NewsHeader from "./NewsHeader";
import { fetchNewsServices, IMAGE_URL } from "../../API/api";

function News({ language }) {
  const [newsItems, setNewsItems] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 3;
  const navigate = useNavigate();

  useEffect(() => {
    const getNewsServices = async () => {
      try {
        const response = await fetchNewsServices();
        setNewsItems(response.data);
      } catch (error) {
        console.error("Error fetching news services data:", error);
      }
    };
    getNewsServices();
  }, []);

  const totalPages = Math.ceil(newsItems.length / itemsPerPage);
  const displayedItems = newsItems.slice(currentPage * itemsPerPage, (currentPage + 1) * itemsPerPage);

  const handleReadMore = (id) => {
    navigate(`/news/${id}`);
  };

  return (
    <>
      <NewsHeader language={language} />
      <div className="container mt-5"  dir={language === "en" ? "ltr" : "rtl"}>
        <h2 className="text-center mb-5">
          {language === "en" ? "News & Updates" : "الأخبار والتحديثات"}
        </h2>
        
        {displayedItems.map((item) => {
          const date = item.createdAt ? new Date(item.createdAt) : new Date();
          const day = date.getDate();
          const month = date.toLocaleString("default", { month: "long" });

          const imageUrl = item.image.startsWith('http://127.0.0.1:5008')
            ? item.image.replace('http://127.0.0.1:5008', IMAGE_URL)
            : item.image;

          return (
            <div className="row mb-4" key={item.id}>
              <div dir={language === "en" ? "ltr" : "rtl"} className="col-md-2 col-sm-3 date-container text-center">
                <div className="date-box shadow">
                  <div className="day">{day}</div>
                  <div className="month">{month}</div>
                </div>
              </div>
              <div className="col-md-10 col-sm-9">
                <div className="news-card shadow-sm">
                  <img
                    src={imageUrl}
                    alt={item.title[language]}
                    className="news-image"
                  />
                  <div className="news-content">
                    <h5 className="news-title">{item.title?.[language] || item.title.en}</h5>
                    <div className="row">
                      <div className="col-md-10">
                        <p
                          className="news-description truncate"
                          dangerouslySetInnerHTML={{ __html: item.description?.[language] || item.description.en }}
                        ></p>
                      </div>
                      <div className="col-md-2 mt-4">
                        {item.description[language] && (
                          <button
                            className="btn btn-primary"
                            onClick={() => handleReadMore(item.id)}
                          >
                            {language === "en" ? "Read More →" : "اقرأ المزيد →"}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        <div className="d-flex justify-content-center align-items-center mt-4 pb-5">
          <button
            type="button"
            className="btn btn-outline-secondary me-2"
            onClick={() => setCurrentPage(currentPage - 1)}
            disabled={currentPage === 0}
          >
            &larr;
          </button>

          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              type="button"
              className={`btn btn-outline-secondary me-2 ${currentPage === index ? 'active' : ''}`}
              onClick={() => setCurrentPage(index)}
            >
              {index + 1}
            </button>
          ))}

          <button
            type="button"
            className="btn btn-outline-secondary me-2"
            onClick={() => setCurrentPage(currentPage + 1)}
            disabled={currentPage === totalPages - 1}
          >
            &rarr;
          </button>
        </div>
      </div>
    </>
  );
}

export default News;
