// src/components/NewsDetail.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { fetchNewsServices, IMAGE_URL } from "../../API/api"; // Import the fetch function and image URL
// import './NewsDetails.css';
function NewsDetail({ language }) {
  const { id } = useParams(); // Get the news ID from the URL
  const [newsItem, setNewsItem] = useState(null);

  useEffect(() => {
    const getNewsItem = async () => {
      try {
        const response = await fetchNewsServices(); // Fetch all news items
        const item = response.data.find((news) => news.id === id); // Find the specific item by ID

        // Update the image URL if it starts with 'http://127.0.0.1:5008'
        if (item && item.image.startsWith('http://127.0.0.1:5008')) {
          item.image = item.image.replace('http://127.0.0.1:5008', IMAGE_URL); // Replace with IMAGE_URL constant
        }

        setNewsItem(item);
      } catch (error) {
        console.error("Error fetching news item:", error);
      }
    };
    getNewsItem();
  }, [id]);

  if (!newsItem) return <p>Loading...</p>;

  return (
    <div className="container mt-5"  dir={language === "en" ? "ltr" : "rtl"}>
      <h2 className="text-center mb-5">{newsItem.title[language]}</h2>
      <img
        src={newsItem.image} // Use the updated image URL
        alt={newsItem.title[language]}
        className="news-image"
      />
      <p
        dangerouslySetInnerHTML={{ __html: newsItem.description[language] }}
      ></p>
    </div>
  );
}

export default NewsDetail;
