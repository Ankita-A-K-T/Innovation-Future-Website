import React, { useState, useEffect } from 'react';
import './News.css';
import {fetchPortfolioItems, IMAGE_URL } from '../../API/api';

function NewsHeader({ language }) {
  const [imageData, setImageData] = useState(null);
  
  // Fetch data from the API on component mount
   useEffect(() => {
    const fetchImageData = async () => {
      try {
        // Use the centralized API method to fetch portfolio data
        const response = await fetchPortfolioItems();
        
        // Access the portfolio items from the response
        const data = response.data;
        
        // Find the image data with the specific ID
        const selectedData = data.find(item => item._id === "673888ef34f49533c26660e1");
        
        if (selectedData) {
          setImageData(selectedData.image); // Set the image path to the state
        }
      } catch (error) {
        console.error("Error fetching image data:", error);
      }
    };
    
    fetchImageData();
  }, []);

  return (
    <>
      <div 
        className="newimg"
        style={{
          backgroundImage: imageData ? `url('${IMAGE_URL}${imageData}')` : "url('/image/Newsback.jpeg')", // Use the fetched image or fallback image
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: '130vh',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          textAlign: 'center',
          color: 'white',
        }}
      >
        <div 
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.50)',
            zIndex: 1,
          }}
        />
        <div style={{ position: 'relative', zIndex: 2 }}>
          <h1 style={{ fontSize: '4rem', lineHeight: '1.2' }}>
            {language === "en" ? "News & Updates" : "الأخبار والتحديثات "}
          </h1>
        </div>
      </div>
    </>
  );
}

export default NewsHeader;
