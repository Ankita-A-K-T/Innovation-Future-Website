import React from 'react';
import PortfolioBody from './PortfolioBody';
import PortfolioHero from './PortfolioHero';

function Portfolio({language}) {
    return ( 
        <>
        <PortfolioHero language={language}/>
       <PortfolioBody language={language}/>
        </>
     );
}

export default Portfolio;