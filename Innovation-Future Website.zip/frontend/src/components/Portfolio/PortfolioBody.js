import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Portfolio.css';
import { IMAGE_URL, fetchPortfolio } from '../../API/api';

function PortfolioBody({ language }) {
  const [projects, setProjects] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const cardsPerPage = 3;
  const navigate = useNavigate();

  useEffect(() => {
    const loadProjects = async () => {
      try {
        const response = await fetchPortfolio(); // Use the API function
        const data = response.data; // Access `data` from Axios response

        const transformedProjects = data.map((project) => ({
          image: `${IMAGE_URL}${project.image}`,
          title: project.title,
          description: project.description,
          link: '#',
        }));

        setProjects(transformedProjects);
      } catch (error) {
        console.error('Error fetching projects:', error);
      }
    };

    loadProjects();
  }, []);

  const totalPages = Math.ceil(projects.length / cardsPerPage);

  const handleArrowClick = (direction) => {
    setCurrentPage((prevPage) =>
      direction === 'left'
        ? (prevPage === 0 ? totalPages - 1 : prevPage - 1)
        : (prevPage === totalPages - 1 ? 0 : prevPage + 1)
    );
  };

  const startIndex = currentPage * cardsPerPage;
  const currentProjects = projects.slice(startIndex, startIndex + cardsPerPage);

  const handleReadMore = (project) => {
    navigate('/project-detail', { state: project });
  };

  return (
    <div
      className="container-fluid image-switcher-container text-center p-5 bottom-padding"
      dir={language === 'en' ? 'ltr' : 'rtl'}
    >
      <h2 className="pb-3" style={{ color: 'white' }}>
        {language === 'ar' ? 'مشاريعنا ' : 'Our Successful Projects'}
      </h2>

      <div className="row justify-content-center">
        {currentProjects.map((project, index) => (
          <div className="col-11 mb-4 col-sm-11" key={index}>
            <div className="card protofolioCard">
              <img
                src={project.image}
                className="card-img-top protfolioimg"
                alt={project.title[language]}
              />

              <div className="card-body d-flex flex-column justify-content-between protofoliocbody">
                <div>
                  <h5 className="card-title portfolioTitle ps-5">
                    {project.title[language]}
                  </h5>
                  <p
                    dir={language === 'en' ? 'ltr' : 'rtl'}
                    className="card-text portfolioDescription"
                    dangerouslySetInnerHTML={{
                      __html: project.description[language],
                    }}
                  ></p>
                </div>
                <div className="text-end mt-auto">
                  <button
                    onClick={() => handleReadMore(project)}
                    className="btn btn-outline-dark Readmore"
                  >
                    {language === 'ar' ? 'اقرأ المزيد' : 'Read More'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="d-flex justify-content-center align-items-center mt-4"  dir="ltr">
        <button
          type="button"
          className="btn btn-outline-secondary me-2"
          onClick={() => handleArrowClick('left')}
        >
          &larr;
        </button>

        {Array.from({ length: totalPages }).map((_, index) => (
          <button
            key={index}
            type="button"
            className={`btn btn-outline-secondary me-2 ${
              currentPage === index ? 'active' : ''
            }`}
            onClick={() => setCurrentPage(index)}
          >
            {index + 1}
          </button>
        ))}

        <button
          type="button"
          className="btn btn-outline-secondary "
          onClick={() => handleArrowClick('right')}
        >
          &rarr;
        </button>
      </div>
    </div>
  );
}

export default PortfolioBody;
