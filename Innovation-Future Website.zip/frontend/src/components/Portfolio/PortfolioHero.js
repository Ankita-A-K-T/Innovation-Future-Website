import React, { useEffect, useState } from 'react';
import {fetchPortfolioItems, IMAGE_URL } from '../../API/api';
function PortfolioHero({ language }) {
  const [portfolioData, setPortfolioData] = useState(null);
  const [error, setError] = useState(null);
  const id = '6731e4a47059bcd8ece45215'; // ID for filtering

  useEffect(() => {
    // Fetch the data
    const fetchPortfolioData = async () => {
  try {
    const response = await fetchPortfolioItems(); // Axios already returns data
    const data = response.data; // Access data from Axios response

    // Find the portfolio item with the matching ID
    const portfolioItem = data.find((item) => item._id === id);
    setPortfolioData(portfolioItem);
  } catch (err) {
    setError(err.message); // Handle errors
  }
};


    fetchPortfolioData();
  }, [id]);

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!portfolioData) {
    return <div>Loading...</div>;
  }

  const { title, image } = portfolioData;
  const imageUrl = `${IMAGE_URL}${image}`; // Construct full image URL

  return (
    <div className="position-relative"  dir={language === "en" ? "ltr" : "rtl"}>
      <img
        className="d-block w-100 carousel-image"
        src={imageUrl}
        alt={title.en}
      />
      <div
        className="position-absolute bottom-0 text-light"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          width: '100%',
          padding: '10px',
        }}
      >
        <h1 className="heroportfolio">{title[language] }</h1>
      </div>
    </div>
  );
}

export default PortfolioHero;
