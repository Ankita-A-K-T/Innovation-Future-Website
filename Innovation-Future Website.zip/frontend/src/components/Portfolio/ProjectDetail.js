import React from "react";
import { useLocation } from "react-router-dom";
import './Portfolio.css';

function decodeHtml(html) {
  const txt = document.createElement("textarea");
  txt.innerHTML = html;
  return txt.value;
}

function ProjectDetail({ language }) {
  const location = useLocation();
  const { title, description, image, link } = location.state || {};

  // Use the selected language (default to "en" if not available)
  const selectedTitle = title?.[language] || title?.en || "Default Title";
  const selectedDescription = description?.[language] || description?.en || "Default Description";

  // Decode HTML entities in the description
  const decodedDescription = decodeHtml(selectedDescription);

  return (
    <div className="container mt-5"  dir={language === "en" ? "ltr" : "rtl"}>
      <h2>{selectedTitle}</h2>
      <img src={image} alt={selectedTitle} className="img-fluid mb-4 " />
      <div dangerouslySetInnerHTML={{ __html: decodedDescription }}></div>
      {link && (
        <a href={link} className="btn btn-primary" target="_blank" rel="noopener noreferrer">
          Visit Project
        </a>
      )}
    </div>
  );
}

export default ProjectDetail;
