import React, { useEffect, useState } from 'react';
import './Privacy.css';
import {fetchprivacy,IMAGE_URL } from "../../API/api";

function PrivacypolicyHeader({ language }) {
    const [imageUrl, setImageUrl] = useState(null);
   

    useEffect(() => {
        // Fetch data from the API
        const fetchImage = async () => {
            try {
                const response = await fetchprivacy();
                const data = await response.data;
                const privacyData = data.find(item => item._id === "67374e345057185fb4680c01");
                if (privacyData) {
                    setImageUrl(`${IMAGE_URL}${privacyData.image}`);
                }
            } catch (error) {
                console.error("Error fetching privacy image:", error);
            }
        };
        fetchImage();
    }, []);

    return (
        <>
            {/* Hero Section */}
            <div
                className="privacyimg"
                style={{
                    backgroundImage: `url(${imageUrl || '/placeholder.jpg'})`, // Use fetched image or a placeholder
                    position: 'relative',
                    height: '90vh',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                }}
            >
                {/* Shading overlay */}
                <div
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.50)',
                        zIndex: 1,
                    }}
                />
                <div style={{ position: 'relative', zIndex: 2 }}>
                    <h1 className="privacyhead"> {language === "en" ? "Privacy Policy" : "سياسة الخصوصية"}</h1>
                </div>
            </div>
        </>
    );
}

export default PrivacypolicyHeader;
