import React, { useState, useEffect } from 'react';
import { fetchService } from '../../API/api'; 
import './Services.css'; 
import { IMAGE_URL } from '../../API/api';

function ServiceCard({ language, onLanguageSwitch }) { // Accept language and switch function as props
  const [services, setServices] = useState([]);

  useEffect(() => {
    const getServices = async () => {
      try {
        const response = await fetchService(); // Call the API function
        setServices(response.data); // Set the services data from the API response
      } catch (error) {
        console.error("Error fetching services:", error);
      }
    };

    getServices();
  }, []);

  return (
    <div className="container-fluid p-5" dir={language === "en" ? "ltr" : "rtl"}>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h3 className="ServiceCardh3 ps-3">
          {language === "en" ? (
            <>
              Our technology division is committed to delivering innovative solutions that empower businesses to leverage the latest advancements in technology. We offer a range of services from expert consultation to custom application development, all designed to meet your specific needs.
            </>
          ) : (
            <>
               يلتزم قسم التكنولوجيا لدينا بتقديم حلول مبتكرة تمكن الشركات من الاستفادة من أحدث التطورات التكنولوجية. نحن نقدم مجموعة من الخدمات، بدءًا من الاستشارات المتخصصة ووصولاً إلى تطوير التطبيقات المخصصة، وكلها مصممة بناءا على احتياجات عملاءنا.
            </>
          )}
        </h3>
        <button 
          className="btn btn-primary" 
          onClick={onLanguageSwitch} // Trigger the language switch function
        >
          {language === "en" ? "Switch to Arabic" : "Switch to English"}
        </button>
      </div>

      <div className="row justify-content-center pt-5">
        {services.length > 0 ? ( // Check if services are loaded
          services.map((service) => (
            <div className="col-lg-3 col-md-4 col-sm-6 mb-4" key={service._id}>
              <div className="service-card">
                <img 
                  src={`${IMAGE_URL}${service.image}`} // Use the correct image URL
                  alt={`Service ${service.title.en}`} 
                  className="service-card-img"
                />
                <div className="service-card-bottom-overlay p-3">
                <p
  className="p-2 m-0"
  style={{
    borderLeft: language === "ar" ? "none" : "3px solid #00C165",
    borderRight: language === "ar" ? "3px solid #00C165" : "none",
  }}
>
  {service.title?.[language] || service.title.en}.
</p>
                </div>
                <div className="service-card-hover-overlay p-5">
                  <h4 className="pt-5">{service.title?.[language] || service.title.en}</h4>
                  <p>{service.description?.[language] || service.description.en}</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>Loading services...</p>
        )}
      </div>

      <a type="button" href="#serviceContact" className="btn btn-outline-dark custom-button">
        {language === "en" ? "Request Your Services" : "اطلب خدماتك"}
      </a>
    </div>
  );
}

export default ServiceCard;
