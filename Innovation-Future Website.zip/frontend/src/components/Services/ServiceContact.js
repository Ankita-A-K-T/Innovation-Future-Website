import React, { useEffect, useState } from 'react';
import { fetchService } from '../../API/api'; // Import API function to fetch services
import './Services.css'; // Import CSS file
import { createContactus } from '../../API/api'; // Import POST API for Contact Us

// List of country codes
const countryCodes = [
  { code: "+91" ,},
  { code: "+1", },
  { code: "+44", },
  { code: "+61", },
  { code: "+971",  },
  { code: "+966",  },
  { code: "+81",  },
  { code: "+49",  },
  { code: "+33", },
  { code: "+55",  },
  { code: "+86", },
  { code: "+7",  },
  { code: "+82",  },
  { code: "+39", },
  { code: "+34", },
  { code: "+63",  },
  { code: "+65",  },
  { code: "+27", },
  { code: "+64",  },
  { code: "+92", },
  { code: "+880",  },
  { code: "+20", },
  { code: "+66", },
  { code: "+60",  },
  { code: "+52", },
  { code: "+46",  },
  { code: "+41",  },
  { code: "+31", },
  { code: "+32",  },
  { code: "+48",  },
  { code: "+353", },
  { code: "+47",  },
  { code: "+90",  },
  { code: "+43",  },
  { code: "+351",  },
  { code: "+372", },
  { code: "+380", },
  { code: "+58", },
  // Add other country codes as needed
];

function ContactForm({ language }) {
  const [services, setServices] = useState([]);
  const [formValues, setFormValues] = useState({
    fullName: "",
    email: "",
    phoneNumber: "",
    service: "",
    message: "",
    countryCode: "+966",
  });
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submissionMessage, setSubmissionMessage] = useState("");

  useEffect(() => {
    const getServices = async () => {
      try {
        const response = await fetchService();
        setServices(response.data);
      } catch (error) {
        console.error("Error fetching services:", error);
      }
    };

    getServices();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const validate = () => {
    const errors = {};

    if (!formValues.fullName.trim()) {
      errors.fullName = "Full Name is required";
    }
    if (!formValues.email) {
      errors.email = "Email is required";
    } else if (!/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(formValues.email)) {
      errors.email = "Please enter a valid email address";
    }
    if (!formValues.phoneNumber) {
      errors.phoneNumber = "Phone Number is required";
    } else if (formValues.phoneNumber.length < 10) {
      errors.phoneNumber = "Phone Number should be at least 10 digits";
    }
    if (!formValues.service) {
      errors.service = "Please select a service";
    }
    if (!formValues.message.trim()) {
      errors.message = "Message cannot be empty";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      try {
        const response = await createContactus({
          name: formValues.fullName,
          email: formValues.email,
          phone: `${formValues.countryCode}${formValues.phoneNumber}`,
          service: formValues.service,
          message: formValues.message,
        });
        setSubmissionMessage("Form submitted successfully!");
        setIsSubmitted(true);
        setFormValues({
          fullName: "",
          email: "",
          phoneNumber: "",
          service: "",
          message: "",
          countryCode: "+966",
        });
      } catch (error) {
        console.error("Error submitting form:", error);
        setSubmissionMessage("Failed to submit the form. Please try again.");
      }
    } else {
      setIsSubmitted(false);
    }
  };

  return (
    <div className="container Servicecontact" id="serviceContact"  dir={language === "en" ? "ltr" : "rtl"} >
      <form className="form" onSubmit={handleSubmit}>
        <div className="input-group">
          <input
            type="text"
            name="fullName"

              placeholder={language === "en" ? "Full Name" : "الاسم الكامل "}
            className={`input-field ${formErrors.fullName ? "input-error" : ""}`}
            value={formValues.fullName}
            onChange={handleChange}
          />

          <input
            type="email"
            name="email"
          
             placeholder={language === "en" ? "Email" : "البريد الالكتروني "}
            className={`input-field ${formErrors.email ? "input-error" : ""}`}
            value={formValues.email}
            onChange={handleChange}
          />
        </div>

        <div className="input-group">
          <div className="phone-group">
            <select
              name="countryCode"
              value={formValues.countryCode}
              onChange={handleChange}
              className={`country-code-selector ${formErrors.phoneNumber ? "input-error" : ""}`}
              style={{ color: 'white', backgroundColor: '#0B1A40', border: '1px solid #8EABE5' }}
            >
              {countryCodes.map((country) => (
                <option key={country.code} value={country.code}>
                  {country.label} {country.code}
                </option>
              ))}
            </select>
            <input
              type="tel"
              name="phoneNumber"
            
               placeholder={language === "en" ? "Phone Number" : "رقم الهاتف   "}
               className={`${formErrors.phoneNumber ? "input-error" : ""} phonemargin`}
             
              value={formValues.phoneNumber}
              onChange={handleChange}
            />
          </div>

          <select
            name="service"
            className={`input-field ${formErrors.service ? "input-error" : ""}`}
            value={formValues.service}
            onChange={handleChange}
          >
            <option value="" >  {language === "en" ? <>Choose your Service </> : <>اختر الخدمة  </>}</option>
            {services.map(service => (
              <option key={service._id} value={service.title.en}>
                {service.title.en}
              </option>
            ))}
          </select>
        </div>

        <div className="textarea-submit-group">
          <textarea
            name="message"
          
             placeholder={language === "en" ? "Write Your Message" : "اكتب رسالتك"}
            rows="4"
            className={formErrors.message ? "input-error" : ""}
            value={formValues.message}
            onChange={handleChange}
          ></textarea>

          <button type="submit">  {language === "en" ? <>Submit </> : <>ارسال </>}</button>
          {isSubmitted && <p className="success-message">{submissionMessage}</p>}
        </div>
      </form>
    </div>
  );
}

export default ContactForm;
