import React, { useEffect, useState } from 'react';
import { fetchServiceGoals, IMAGE_URL } from '../../API/api'; // Import the API function and image base URL

function ServiceGoal({ language }) {
  const [serviceGoal, setServiceGoal] = useState(null);

  useEffect(() => {
    // Fetch the data using the API function
    fetchServiceGoals()
      .then((response) => {
        const data = response.data;
        if (data && data.length > 0) {
          setServiceGoal(data[0]); // Assuming you need the first item in the array
        }
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  return (
    <div className="container-fluid pb-3" dir={language === "en" ? "ltr" : "rtl"} >
      {/* Check if serviceGoal has been set */}
      {serviceGoal ? (
        <div className="row p-5 pb-0">
          <div className="col-md-6 d-flex align-items-center">
            <div className="Gole-text ps-4" >
              {/* Use the language prop to switch descriptions */}
              <p>{serviceGoal.description[language] || serviceGoal.description.en}</p>
            </div>
          </div>
          <div className="col-md-6">
            <div className="innovation-image">
              <img
                src={`${IMAGE_URL}${serviceGoal.image}`}
                alt="Service"
                className="img-fluid"
              />
            </div>
          </div>
        </div>
      ) : (
        <p>Loading...</p> // Show loading text while fetching data
      )}
    </div>
  );
}

export default ServiceGoal;
