import React, { useEffect, useState } from "react";
import { fetchServiceInnovation, IMAGE_URL } from "../../API/api";
import "./Services.css";

function ServiceInnovation({ language }) {
  const [services, setServices] = useState([]);

  useEffect(() => {
    const getServices = async () => {
      try {
        const response = await fetchServiceInnovation();
        setServices(response.data);
      } catch (error) {
        console.error("Error fetching service data:", error);
      }
    };

    getServices();
  }, []);

  return (
    <div className="container-fluid text-white align-items-center text-center pb-5 inovation-container" >
      <h3 className="p-4 ServiceInnovation-para1">
        {language === "en"
          ? "Technology and Innovation Services"
          : "الخدمات التقنية المتقدمة  "}
      </h3>
      <h3 className="ServiceInnovation-para2 pb-5 ps-5 pe-5">
        {language === "en"
          ? "Our technology division is dedicated to providing cutting-edge solutions that enable businesses to harness the power of emerging technologies. By staying at the forefront of innovation, we ensure that each solution is tailored to drive growth, efficiency, and long-term success."
          : "يقوم قسم تقنية المعلومات لدينا بتوفير حلول مبتكرة تتيح للأعمال الاستفادة القصوى من التقنيات المتقدمة. من خلال مواكبة احدث التطورات في المجال التقني، نضمن أن الخدمات المقدمة تصمم بعناية لدفع النمو والكفاءة والنجاح .  "}
      </h3>

      <div className="row d-flex justify-content-between align-items-center text-center" style={{ gap: "20px" }}>
        <div className="d-flex justify-content-between align-items-center innovation-row" style={{ width: "100%" }}>
          {services.length > 0 &&
            services.slice(0, 3).map((service, index) => (
              <React.Fragment key={index}>
                <div style={{ flex: 1 }}>
                  <img
                    src={`${IMAGE_URL}${service.icon.replace(/\\/g, '/')}`}
                    className="vision-image"
                    alt={service.title[language] || service.title.en}
                  />
                  <h6 className="innovationh7 pt-4">
                    {service.title[language] || service.title.en}
                  </h6>
                  <p className="Serviceinnovationhp">
                    {service.description[language] || service.description.en}
                  </p>
                </div>
                {index < 2 && <div className="vertical-line"></div>}
              </React.Fragment>
            ))}
        </div>
      </div>

      <div className="text-center mt-4 pb-3">
        <a
          href="#serviceContact"
          type="button"
          className="btn btn-outline-light custom-button ps-5 pe-5"
        >
          {language === "en" ? "Request Your Services" : "اطلب الخدمة "}
        </a>
      </div>
    </div>
  );
}

export default ServiceInnovation;
