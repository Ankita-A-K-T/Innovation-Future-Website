import React, { useEffect, useState } from 'react';
import { fetchServiceSupport, IMAGE_URL } from '../../API/api'; // Import the API function and image URL
import './Services.css';

function ServiceRequest({ language }) {
  const [services, setServices] = useState([]);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await fetchServiceSupport();
        setServices(response.data);
      } catch (error) {
        console.error("Error fetching services:", error);
      }
    };

    fetchServices();
  }, []);

  return (
    <div className="container-fluid Requestcontainer" dir={language === "en" ? "ltr" : "rtl"}>
      <div className="row p-5 pb-0">
        <p className="p-4 text-white requestpara">
          {language === "en" ? (
            <>In our Strategic Business Support Division, we guide entrepreneurs and startups through every stage of their growth journey. From initial development to scaling and beyond, we offer tailored solutions that adapt to your evolving needs.</>
          ) : (
            <> في قطاع المشاريع لدينا، نوجه رواد الأعمال والشركات الناشئة خلال كل مرحلة من مراحل نموهم. من مرحلة ما قبل البذرة  إلى التوسع والنمو نحن نستخدم خبراتنا المتراكمة لتقديم حلولاً مخصصة تتكيف مع احتياجاتك المتغيرة.</>
          )}
        </p>

        {services.length > 0 && (
          <>
            {/* Service 1 */}
            <div className="col-md-6 d-flex justify-content-center align-items-center mb-3">
              {services[2]?.image && (
                <div className="service-card position-relative srimg">
                  <img
                    src={`${IMAGE_URL}${services[2].image.replace(/\\/g, '/')}`}
                    alt="Image 1"
                    className="service-card-img img-fluid serimg"
                  />
                  <p className="image-text">
                    {language === "en" ? services[2].title?.en : services[2].title?.ar}
                  </p>
                  <div className="service-card-hover-overlay">
                    <p>{language === "en" ? services[2].subtitle?.en : services[2].subtitle?.ar}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Service 2 */}
            <div className="col-md-6 d-flex flex-column justify-content-between pt-3">
              {services[1]?.image && (
                <div className="service-card position-relative mb-2">
                  <img
                    src={`${IMAGE_URL}${services[1].image.replace(/\\/g, '/')}`}
                    alt="Image 2"
                    className="service-card-img img-fluid"
                    style={{ borderLeft: '5px solid #00C165' }}
                  />
                  <p className="image-text">
                    {language === "en" ? services[1].title?.en : services[1].title?.ar}
                  </p>
                  <div className="service-card-hover-overlay">
                    <p>{language === "en" ? services[1].subtitle?.en : services[1].subtitle?.ar}</p>
                  </div>
                </div>
              )}

              {/* Service 3 */}
              {services[0]?.image && (
                <div className="service-card position-relative mt-2 pb-3">
                  <img
                    src={`${IMAGE_URL}${services[0].image.replace(/\\/g, '/')}`}
                    alt="Image 3"
                    className="service-card-img img-fluid"
                    style={{ borderLeft: '5px solid #00C165' }}
                  />
                  <p className="image-text image-text2">
                    {language === "en" ? services[0].title?.en : services[0].title?.ar}
                  </p>
                  <div className="service-card-hover-overlay service-card-hover-overlay2 ">
                    <p>{language === "en" ? services[0].subtitle?.en : services[0].subtitle?.ar}</p>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      <div className="text-center mt-4 pb-5">
        <a href="#serviceContact" type="button" className="btn btn-outline-light custom-button ps-5 pe-5">
          {language === "en" ? <>Request Your Service</> : <>اطلب خدمتك</>}
        </a>
      </div>
    </div>
  );
}

export default ServiceRequest;
