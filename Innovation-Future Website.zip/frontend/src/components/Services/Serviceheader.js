import React, { useEffect, useState } from 'react';
import { fetchServiceHero, IMAGE_URL } from '../../API/api'; // Import from api.js
import './Services.css';

function Serviceheader({ language }) { // Accept language as a prop
  const [serviceData, setServiceData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetchServiceHero();
        setServiceData(response.data[0]); // Assuming the response is an array
      } catch (error) {
        console.error("Error fetching service data:", error);
      }
    };

    fetchData();
  }, []);

  if (!serviceData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="position-relative" dir={language === "en" ? "ltr" : "rtl"}>
      <img
        className="d-block w-100 service-image"
        src={`${IMAGE_URL}${serviceData.image}`}
        alt="Service Hero"
      />
      <div
        className="position-absolute srvhead bottom-0 text-light w-100 ps-5"
        style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
      >
        <h2 className="Serviceheroh2 ps-3">
          {serviceData.title[language] || serviceData.title.en} {/* Use selected language or fallback to English */}
        </h2>
        <p className="Serviceherop">
          {serviceData.subtitle[language] || serviceData.subtitle.en}
        </p>
      </div>
      <div className="blue-background position-absolute left-center">
        <p className="blue-paragraph">
          {serviceData.description[language] || serviceData.description.en}
        </p>
      </div>
    </div>
  );
}

export default Serviceheader;
