import React from 'react';
import ServiceRequest from './ServiceRequest';
import ServiceCard from './ServiceCard';
import ServiceInovation from './ServiceInnovation';
import ServiceContact from './ServiceContact';
import ServiceGoal from './ServiceGoal';
import Serviceheader from './Serviceheader';

function Services({language}) {
    return ( 
        <>
        <Serviceheader language={language}/>
        <ServiceInovation language={language}/>
        <ServiceCard language={language} />
        <ServiceRequest language={language}/>
        <ServiceGoal language={language}/>
        <ServiceContact language={language}/>
       <br/>
       <br/>
        </>
     );
}

export default Services;