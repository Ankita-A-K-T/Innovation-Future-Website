import React, { useEffect, useState } from 'react';
import './Term.css';
import {fetchprivacy,IMAGE_URL } from "../../API/api";

function TermconditionHeader({ language }) {
    
     const [imageUrl, setImageUrl] = useState(null);
   

    useEffect(() => {
        // Fetch data from the API
        const fetchImage = async () => {
            try {
                const response = await fetchprivacy();
                const data = await response.data;
                const privacyData = data.find(item => item._id === "67374bff5057185fb4680bfd");
                if (privacyData) {
                    setImageUrl(`${IMAGE_URL}${privacyData.image}`);
                }
            } catch (error) {
                console.error("Error fetching privacy image:", error);
            }
        };
        fetchImage();
    }, []);
    
    return ( 
        <>
     {/* Hero Section */}
     <div className="termimg"
                style={{
                    
                   backgroundImage: `url(${imageUrl || '/placeholder.jpg'})`, // Directly use the image URL
                    
                    
                }}
            >
              {/* Adjusted the opacity to reduce the shading */}
              <div 
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.50)', // Reduced opacity from 0.5 to 0.3
                        zIndex: 1,
                    }}
                />
                <div style={{ position: 'relative', zIndex: 2  }}>
                    <h1 classname="soon" style={{ fontSize: '4rem', lineHeight: '1.2' ,    textAlign: 'center', }}>{language === "en" ? "Terms & Conditions" : "الشروط والأحكام"}</h1>
                </div>
            </div>
        </>

        
     );
}

export default TermconditionHeader;