import React, { useEffect, useState } from 'react'; // Import hooks
import './Term.css';
import TermconditionHeader from './TermconditionHeader';
import { fetchprivacy } from '../../API/api'; // Import the fetchPrivacyPolicy function

function TermsAndconditions({language}) {
    const [termsData, setTermsData] = useState(null);

  useEffect(() => {
    // Fetch Terms and Conditions data when component mounts
    const fetchData = async () => {
      try {
        const response = await fetchprivacy(); // Use imported fetch function
        const data = response.data;

        if (data && Array.isArray(data)) {
          const terms = data.find(item => item._id === "67374bff5057185fb4680bfd");
          setTermsData(terms); // Set Terms & Conditions data
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  if (!termsData) {
    return <div>Loading...</div>;
  }

  return (
    <div>
    <TermconditionHeader language={language}/>
     
      
      <div className="container-fluid ps-5 p-3" style={{ backgroundColor: "#ffffff" }}  dir={language === "en" ? "ltr" : "rtl"}>
        <div className="row p-lg-5 p-md-4 p-sm-3 p-2">
          <div className="col-12">
            {/* Center-align the heading */}
            <div className="text-center">
              <div className="heading-wrapper pb-5 d-flex justify-content-center align-items-center">
               
                <h2 className="heading-text">
                  {language === "en" ? termsData.title.en : termsData.title.ar}
                </h2>
               
              </div>
            </div>

            <div
              className="introp"
               style={{color:"#002753"}}
              dangerouslySetInnerHTML={{
                __html: language === "en" ? termsData.description.en : termsData.description.ar,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default TermsAndconditions;
