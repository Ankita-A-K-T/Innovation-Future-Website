import React, { useState, useEffect } from 'react';
import { fetchCards, IMAGE_URL } from '../../API/api';
import './Card.css';

function Card({ language }) {
  const [allImages, setAllImages] = useState([]);
  const [visibleImages, setVisibleImages] = useState(6);

  useEffect(() => {
    const getCards = async () => {
      try {
        const response = await fetchCards();
        console.log("Fetched cards:", response.data);

        const transformedData = response.data.map(item => ({
          url: `${IMAGE_URL}${item.image}`,
          paragraph: item.title,
          additional: item.description
        }));

        setAllImages(transformedData);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    getCards();
  }, []);

  const loadMoreImages = () => {
    setVisibleImages((prevVisibleImages) => prevVisibleImages + 3);
  };

  return (
    <div
      className="container-fluid p-5"
      dir={language === "en" ? "ltr" : "rtl"} // Dynamically set text direction
    >
    <h6 className="cardsh6">
     {language === "en" ? "At Innovation Future" : "في مستقبل الابتكار "} {/* Language specific heading */}
    </h6>
      <h3 className="cardh3 ps-2 pb-3">
        {language === "en"
          ? "We offer a range of services tailored to meet your specific needs"
          : "نحن نوفر مجموعة من الخدمات التي تتناسب مع تطلعاتكم "}
      </h3>

      <div className="row justify-content-center">
        {allImages.slice(0, visibleImages).map((image, index) => (
          <div className="col-md-4 mb-4" key={index}>
            <div className="card-container">
              <img src={image.url} alt={`Service ${index + 1}`} className="card-image" />
              <div className="card-overlay">
               
                <p className="custom-paragraph">{image.paragraph?.[language] || image.paragraph}</p>
              </div>
            </div>
            <p className="additional-paragraph">
              {image.additional?.[language] ||image.additional}
            </p>
          </div>
        ))}
      </div>

      {visibleImages < allImages.length && (
        <button
          type="button"
          className="btn btn-outline-dark custom-button"
          onClick={loadMoreImages}
        >
          {language === "en" ? "Explore Further" : "اكتشف المزيد "}
        </button>
      )}
    </div>
  );
}

export default Card;