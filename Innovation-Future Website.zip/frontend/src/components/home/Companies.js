import React, { useEffect, useState } from "react";
import { fetchCompanies, IMAGE_URL } from "../../API/api";
import "./Companies.css";

function Companies({ language }) {
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    const getCompanies = async () => {
      try {
        const response = await fetchCompanies();
        setCompanies(response.data || []); // Ensure response.data is valid
      } catch (error) {
        console.error("Error fetching companies:", error);
      }
    };
    getCompanies();
  }, []);

  // Duplicate companies for seamless scrolling
  const duplicatedCompanies = [...companies, ...companies];

  return (
    <div className="container-fluid imagefull-container head2">
      <div className="text-center">
        <h2 className="head">
          {language === "en" ? "Companies we work with" : "شركائنا"}
        </h2>
      </div>

      <div className="image-container magintopimage">
        <div className="image-slider">
          {duplicatedCompanies.map((company, index) => (
            <div key={index} className="image-item">
              <img
                src={`${IMAGE_URL}${company?.logo || ""}`} // Fallback to empty string if logo is missing
                className="img-fluid"
                alt={company?.name?.[language] || "Company logo"} // Ensure safety
                style={{
                  height: "100px",
                  width: "200px",
                  objectFit: "contain", // Ensure proper scaling
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Companies;
