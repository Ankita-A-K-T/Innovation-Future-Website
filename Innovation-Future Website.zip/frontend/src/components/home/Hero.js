import React, { useState, useEffect } from 'react';
import { Carousel } from 'react-bootstrap';
import { fetchSliders } from '../../API/api'; 
import './Hero.css';
import { IMAGE_URL } from '../../API/api';
function Hero({language}) {
  const [sliders, setSliders] = useState([]);

 
  useEffect(() => {
    const getSliders = async () => {
      try {
        const response = await fetchSliders();
        setSliders(response.data);
      } catch (error) {
        console.error("Error fetching sliders:", error);
      }
    };
    getSliders();
  }, []);

  return (
    <Carousel className="custom-carousel" interval={2000} controls={false} dir={language === "en" ? "ltr" : "rtl"} >
      {sliders.map((slider) => (
        <Carousel.Item key={slider._id}>
          <img
            className="carousel-image"
            src={`${IMAGE_URL}${slider.image}`} 
            alt={slider.title[language]} // Use the English title for alt text
          />
          <div
            className="position-absolute bottom-0 text-light w-100  ps-5 homeh"
            style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
          >
            <h6 className='heroh6'>{slider.title[language]}</h6>
            <h2 className='heroh2'>{slider.headline[language]}</h2>
            <p className='herop'>{slider.description[language]}</p>
          </div>
        </Carousel.Item>
      ))}
    </Carousel>
  );
}

export default Hero;
