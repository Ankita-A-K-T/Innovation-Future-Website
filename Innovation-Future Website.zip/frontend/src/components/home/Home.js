import React from 'react';


import Hero from './Hero';
import InnovationFuture from './InnovationFuture';
import Card from './Card';

import Subscribe from './Subscribe';
import ImageSwitcher from './ImageSwitcher';
import PeopleSay from './PeopleSay';
import Companies from './Companies';
import SecondCard from './SecondCard';


function Home({language}) {
    return ( 
        <>
        <Hero language={language}/>
        <InnovationFuture language={language}/>
    <Card language={language}/>
    <ImageSwitcher language={language}/>
    <SecondCard language={language}/>
    <Companies language={language}/>
    <PeopleSay language={language}/>
    <Subscribe language={language}/>
        </>
     );
}

export default Home;