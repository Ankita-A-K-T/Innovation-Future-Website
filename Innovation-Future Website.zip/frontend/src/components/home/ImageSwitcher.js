import React, { useState, useEffect } from 'react';
import './ImageSwitcher.css'; // Import the CSS for styling
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa'; // Import icons for arrows
import { fetchServiceSliders } from '../../API/api'; // Import the fetchSliders function
import { IMAGE_URL } from '../../API/api';

function ImageSwitcher({ language }) {
  const [sliders, setSliders] = useState([]); // State to hold sliders data
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Fetch sliders data from API
  useEffect(() => {
    const getSliders = async () => {
      try {
        const response = await fetchServiceSliders();
        setSliders(response.data); // Set the sliders data to state
      } catch (error) {
        console.error('Error fetching sliders:', error);
      }
    };

    getSliders();
  }, []);

  // Function to handle left and right navigation
  const handleArrowClick = (direction) => {
    if (direction === 'less') {
      setCurrentImageIndex((prevIndex) =>
        prevIndex === 0 ? sliders.length - 1 : prevIndex - 1
      );
    } else if (direction === 'greater') {
      setCurrentImageIndex((prevIndex) =>
        prevIndex === sliders.length - 1 ? 0 : prevIndex + 1
      );
    }
  };

  return (
    <div className="container-fluid image-switcher-container text-center"  dir={language === "en" ? "ltr" : "rtl"}>
      <h6 className="service">
        {language === "en" ? "Industries We Serve" : "القطاعات التي نخدمها"} {/* Language specific heading */}
      </h6>
      {/* Image container with overlay text */}
      <div className="imageSwichercontainer p-4 pb-0 position-relative">
        {sliders.length > 0 && ( // Check if sliders data is available
          <>
            <img
              src={`${IMAGE_URL}${sliders[currentImageIndex].image}`} // Ensure to prepend the base URL
              alt="Display"
              className="switcherimage"
            />

            {/* Overlay text positioned on top of the image */}
            <div className="image-overlay position-absolute text-white">
              <h2 className="image-title">
                {sliders[currentImageIndex].title[language]} {/* Use selected language title */}
              </h2>
             
              <h6 className="image-subtitle">
                {sliders[currentImageIndex].category[language]} {/* Use category for subtitle */}
              </h6>
            </div>
          </>
        )}
      </div>

      {/* Inline buttons with less than and greater than buttons */}
      <div className="button-container d-flex justify-content-center align-items-center ps-4 pe-4 mt-3">
        {/* Less Than button */}
        <button
          type="button"
          className="btn btn-outline-secondary me-2 rounded-circle arrow-button"
          onClick={() => handleArrowClick('less')}
        >
          <FaChevronLeft className="arrow-icon" /> {/* Left arrow icon */}
        </button>

        {/* Show only the active button on small screens */}
        <div className="w-100 d-flex justify-content-around">
          {sliders.map((slider, index) => (
            <button 
              key={index}
              type="button"
              className={`btn btn-outline-primary me-2 ${currentImageIndex === index ? 'active' : ''} ${
                currentImageIndex === index || window.innerWidth > 576 ? '' : 'd-none' // Hide other buttons on small screens
              }`}
              onClick={() => setCurrentImageIndex(index)}
              style={{
                borderRadius: '0',
                backgroundColor: currentImageIndex === index ? '#00C165' : 'transparent',
                color: currentImageIndex === index ? 'white' : 'white',
                border: currentImageIndex === index ? 'none' : '1px solid white',
              }}
            >
              {slider.category[language]} {/* Language-specific category */}
            </button>
          ))}
        </div>

        {/* Greater Than button */}
        <button
          type="button"
          className="btn btn-outline-secondary ms-2 rounded-circle arrow-button"
          onClick={() => handleArrowClick('greater')}
        >
          <FaChevronRight className="arrow-icon" /> {/* Right arrow icon */}
        </button>
      </div>
    </div>
  );
}

export default ImageSwitcher;
