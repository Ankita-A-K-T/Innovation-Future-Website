import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './InnovationFuture.css';
import { fetchLagacyofExcellence } from '../../API/api'; // Import the API function

function Innovation({ language }) {
    const [data, setData] = useState({ experience: null, industries: null, projects: null });
    const navigate = useNavigate();

    // Fetch data from API on component mount
    useEffect(() => {
        const fetchInnovationData = async () => {
            try {
                const response = await fetchLagacyofExcellence(); // Use the imported function
                const { expreience, industries, projects } = response.data.data[0];
                setData({ experience: expreience, industries, projects });
            } catch (error) {
                console.error('Error fetching innovation data:', error);
            }
        };

        fetchInnovationData();
    }, []);

    const handleExploreMore = () => {
        navigate('/contact-us');
    };

    return (
        <div className='container-fluid text-white align-items-center text-center pb-5 inovation-container'>
            <h3 className='p-5 Innovation-para'>
                {language === "en" ? "Innovation Future By Numbers: A Legacy of Excellence" : " مستقبل الابتكار في ارقام  "}
            </h3>
        
            <div className='row d-flex justify-content-between align-items-center text-center pt-5' style={{ gap: '20px' }}>
                <div className='d-flex justify-content-between align-items-center innovation-row' style={{ width: '100%' }}>
                    <div style={{ flex: 1 }}>
                        <img src="./image/inovation-img1.png" className='vision-image' alt="" />
                        <h6 className='innovationh6 pt-4'>
                            {language === "en" ? `OVER ${data.experience || '...'} YEARS` : `   سنة  ${data.experience || '...'} أكثر من  `}
                        </h6>
                        <h5 className='innovationh5 pt-3'>
                            {language === "en" ? "Years Of Expertise" : "خبراتنا"}
                        </h5>
                    </div>
        
                    {/* Vertical Line 1 */}
                    <div className="vertical-line"></div>
        
                    <div style={{ flex: 1 }}>
                        <img src="./image/inovation-img2.png" className='vision-image' alt="" />
                        <h6 className='innovationh6 pt-4'>
                            {language === "en" ? `MORE THAN ${data.industries || '...'} ` : `أكثر من  ${data.industries || '...'}`}
                        </h6>
                        <h5 className='innovationh5 pt-3'>
                            {language === "en" ? "Industries Covered" : "امجالات عملنا "}
                        </h5>
                    </div>
        
                    {/* Vertical Line 2 */}
                    <div className="vertical-line" id='innovation'></div>
        
                    <div style={{ flex: 1 }}>
                        <img src="./image/inovation-img3.png"  className='vision-image' alt="" />
                        <h6 className='innovationh6 pt-4'>
                            {language === "en" ? `${data.projects || '...'}+` : `${data.projects || '...'}+`}
                        </h6>
                        <h5 className='innovationh5 pt-3'>
                            {language === "en" ? "Successful Projects" : "مشاريعنا "}
                        </h5>
                    </div>
                </div>
            </div>
        
            <p className='p-3 innovationhp'>
                {language === "en" 
                    ? "Since our inception, Innovation Future has been dedicated to delivering top-quality, secure, and adaptable digital solutions that satisfy the needs of today and unlock the opportunities of tomorrow." 
                    : "شركة مستقبل الابتكار هي وجهتك المثالية إن كنت تبحث عن دعم متخصص في رحلة ريادة الأعمال أو تهدف إلى الاستفادة من أحدث الحلول التقنية."
                }
            </p>
        
            <div className="text-center mt-4 pb-3">
                <button 
                    type="button" 
                    className="btn btn-outline-light custom-button ps-5 pe-5" 
                    onClick={handleExploreMore} 
                >
                    {language === "en" ? "Consult Our Experts" : "استشر خبرائنا   "}
                </button>
            </div>
        </div>
    );
}

export default Innovation;
