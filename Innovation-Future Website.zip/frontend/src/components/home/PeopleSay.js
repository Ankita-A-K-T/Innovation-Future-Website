import React, { useState, useEffect } from "react";
import { fetchTestimonials } from '../../API/api'; // Import the fetchTestimonials function
import './PeopleSay.css';
import { IMAGE_URL } from '../../API/api';

function PeopleSay({language}) {
  const [testimonials, setTestimonials] = useState([]); // State to hold testimonials
  const [currentIndex, setCurrentIndex] = useState(0);

  // Fetch testimonials from API on component mount
  useEffect(() => {
    const getTestimonials = async () => {
      try {
        const response = await fetchTestimonials();
        console.log("Fetched testimonials:", response.data); // Log the response data for debugging
        setTestimonials(response.data); // Set the testimonials state with the fetched data
      } catch (error) {
        console.error("Error fetching testimonials:", error);
      }
    };

    getTestimonials();
  }, []); // Empty dependency array to run only once

  // Function to handle button clicks for navigation
  const handleButtonClick = (index) => {
    setCurrentIndex(index);
  };

  // Function to handle left and right arrow navigation
  const handleArrowClick = (direction) => {
    if (direction === 'left') {
      setCurrentIndex((prevIndex) =>
        prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
      );
    } else if (direction === 'right') {
      setCurrentIndex((prevIndex) =>
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
      );
    }
  };

  return (
    <div className="container " dir={language === "en" ? "ltr" : "rtl"}>
      <div className="row">
        {/* Image and testimonial text */}
        <div className="col-md-6 p-5 aboutus-img">
          <h3   className="peopleSayh3 ps-2">{language==="en"?(<>What People Say About Us</>):(<>ماذا قال عنا عملائنا  </>)}</h3>
          {testimonials.length > 0 ? (
            <div className="image-container">
              {/* Green circular icon in the top-right corner */}
              <div className="icon-circle">
  <img src="./image/Vector (5) (1).png" alt="Icon" className="iconimag" />
</div>

              <img
                src={`${IMAGE_URL}${testimonials[currentIndex].image.replace(/\\/g, '/')}`}
                alt="About Us"
                className="img-fluid pt-3"
                style={{ width: '500px', height: '368px' }}
              />
            </div>
          ) : (
            <p>Loading...</p> 
          )}
        </div>
        
        <div className="col-md-6 ppl"  >
          {testimonials.length > 0 ? (
            <>
              <h3 className="peopleSaytitle ">{testimonials[currentIndex].headline?.[language]||testimonials[currentIndex].headline.en}</h3>
              <p className=" peopleSaydescription">{testimonials[currentIndex].description?.[language] || testimonials[currentIndex].description.en}</p>
              <h4 className="peopleSayauthor">{testimonials[currentIndex].name?.[language] || testimonials[currentIndex].name.en}</h4>
             
                <h6 className="peopleSayposition">{testimonials[currentIndex].designation?.[language] || testimonials[currentIndex].designation.en}</h6>
                <h6 className="peopleSayCompany">{testimonials[currentIndex].company?.[language] || testimonials[currentIndex].company.en}</h6>
             
            </>
          ) : (
            <p>Loading...</p> 
          )}
        </div>
      </div>

      {/* Inline buttons with left and right arrows */}
      <div className="d-flex justify-content-center p-4 align-items-center mt-4" dir="ltr">
        {/* Left arrow */}
        <button
          type="button"
          className="btn btn-outline-secondary me-2"
          onClick={() => handleArrowClick('left')}
        >
          &larr;
        </button>

        {/* Buttons for each testimonial */}
        {testimonials.map((_, index) => (
          <button
            key={index}
            type="button"
            className={`btn btn-outline-secondary me-2 ${currentIndex === index ? 'active' : ''}`}
            onClick={() => handleButtonClick(index)}
          >
            {` ${index + 1}`}
          </button>
        ))}

        {/* Right arrow */}
        <button
          type="button"
          className="btn btn-outline-secondary ms-2"
          onClick={() => handleArrowClick('right')}
        >
          &rarr;
        </button>
      </div>
    </div>
  );
}

export default PeopleSay;
