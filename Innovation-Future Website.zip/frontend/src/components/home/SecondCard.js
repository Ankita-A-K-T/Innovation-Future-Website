import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchService, IMAGE_URL } from '../../API/api';
import './SecondCard.css';
import { FaGreaterThan, FaChevronLeft } from 'react-icons/fa'; // Import necessary icons

function SecondCard({ language }) {
    const [cards, setCards] = useState([]);
    const [currentCard, setCurrentCard] = useState(0);
    const navigate = useNavigate();

    useEffect(() => {
        const getCards = async () => {
            try {
                const response = await fetchService();
                setCards(response.data);
            } catch (error) {
                console.error("Error fetching cards:", error);
            }
        };
        getCards();
    }, []);

    const handleExploreClick = () => {
        navigate('/services');
    };

    const handleNext = () => {
        setCurrentCard((prevCard) => (prevCard + 1) % 6); // Limit to 6 cards
    };

    const handlePrev = () => {
        setCurrentCard((prevCard) => (prevCard - 1 + 6) % 6); // Limit to 6 cards
    };

    const renderIcon = (isReverse) => {
        // If reverse for Arabic, render a flipped icon
        return isReverse ? (
            <FaChevronLeft style={{ color: '#00C165', fontSize: '20px',    marginTop: '4px', }} />
        ) : (
            <FaGreaterThan style={{ color: '#00C165', fontSize: '20px' }} />
        );
    };

    return (
        <div className="container-fluid p-5" dir={language === "en" ? "ltr" : "rtl"}>
            <h6 className="texth6">
                {language === "en"
                    ? "Improve and Innovate with the Tech Trends"
                    : "طور وابتكر من خلال احدث الحلول التقنية "}
            </h6>
            <br />
            <h2 className="text ps-3">
                {language === "en"
                    ? "Our team can assist you in transforming your business with the latest tech capabilities to stay ahead of the curve"
                    : "فريقنا على اتم الاستعداد لنقل خدماتك الى مستوى تقني متقدم "}
            </h2>

          {/* For small screens */}
<div className="row mt-5 d-md-none">
    {cards.length > 0 && (
        <div className="col-sm-12 mb-3 secondcardsmallcontener">
            <div className="card text-white released-container">
                <div className="card-body d-flex flex-column flex-sm-row align-items-center">
                    {/* Image Section */}
                    <div className="imgbackground d-flex justify-content-center align-items-center mb-3 mb-sm-0 me-0 me-sm-3">
                        <img
                            className="imgstyle"
                            src={`${IMAGE_URL}${cards[currentCard].icon}`}
                            alt={
                                cards[currentCard].title?.en
                                    ? `${cards[currentCard].title.en} Thumbnail`
                                    : "Service Thumbnail"
                            }
                            style={{
                                maxWidth: '80px',
                                maxHeight: '80px',
                                borderRadius: '8px',
                            }}
                        />
                    </div>
                    
                    {/* Text Section */}
                    <div className="cd2 text-center text-sm-start">
                        <h5
                            className="card-title SecondaryCardTitle"
                            style={{
                                fontSize: '16px',
                                fontWeight: 'bold',
                               
                            }}
                        >
                            {cards[currentCard].title?.[language] ||
                                cards[currentCard].title.en ||
                                "Untitled"}
                        </h5>
                        <p
                            className="card-text released-para1"
                            style={{
                                fontSize: '14px',
                                lineHeight: '18px',
                                color: 'black',
                                marginTop: '8px',
                                textAlign: 'justify',
                            }}
                        >
                            {cards[currentCard].description?.[language] ||
                                cards[currentCard].description.en ||
                                "No description available."}
                        </p>
                    </div>
                </div>
                
                {/* Explore Section */}
                <h6
                    className="explore ms-3 mb-4 text-center"
                    onClick={handleExploreClick}
                    style={{
                        cursor: 'pointer',
                        fontSize: '15px',
                        fontWeight: '600',
                      
                      
                    }}
                >
                    {language === "en" ? "Explore" : "اكتشف"}{' '}
                    {cards[currentCard].title?.[language] || "Service"}{' '}
                    {renderIcon(language === "ar")}
                </h6>
            </div>
        </div>
    )}

   {/* Navigation Buttons */}
<div   className={`d-block text-center mt-3 d-flex justify-content-center ${
        language === "ar" ? "gap-arabic" : ""
    }`}>
    <button
        onClick={handlePrev}
        className="btn prev-next-btn me-3"
        aria-label="Previous"
    >
        <i className="fas fa-chevron-left"></i> {/* Font Awesome left arrow */}
    </button>
    <button
        onClick={handleNext}
        className="btn prev-next-btn"
        aria-label="Next"
    >
        <i className="fas fa-chevron-right"></i> {/* Font Awesome right arrow */}
    </button>
</div>

</div>

            {/* For large screens */}
            <div className="row g-5 mt-5 d-none d-md-flex">
                {cards.length > 0 &&
                    cards.slice(0, 6).map((card, index) => (
                        <div key={index} className="col-md-6 col-sm-12 mb-3">
                            <div className="card text-white released-container">
                                <div className="card-body d-flex flex-row">
                                    <div className="imgbackground align-items-center col-lg-4">
                                        <img
                                            className="imgstyle"
                                            src={`${IMAGE_URL}${card.icon}`}
                                            alt={
                                                card.title?.en
                                                    ? `${card.title.en} Thumbnail`
                                                    : "Service Thumbnail"
                                            }
                                        />
                                    </div>
                                    <div className="ms-5 col-lg-9">
                                        <h5 className="card-title SecondaryCardTitle">
                                            {card.title?.[language] || card.title.en || "Untitled"}
                                        </h5>
                                        <p className="card-text released-para1">
                                            {card.description?.[language] ||
                                                card.description.en ||
                                                "No description available."}
                                        </p>
                                    </div>
                                </div>
                                <h6
                                    className="explore ms-3 mb-4"
                                    onClick={handleExploreClick}
                                    style={{ cursor: 'pointer' }}
                                >
                                    {language === "en" ? "Explore" : "اكتشف"}{' '}
                                    {card.title?.[language] || "Service"}{' '}
                                    {renderIcon(language === "ar")}
                                </h6>
                            </div>
                        </div>
                    ))}
            </div>
        </div>
    );
}

export default SecondCard;
