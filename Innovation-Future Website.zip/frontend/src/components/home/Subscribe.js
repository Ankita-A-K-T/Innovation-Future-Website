import React, { useState, useEffect } from "react";
import { subscribeNewsletter, fetchCompaniesData } from "../../API/api";
import "./Subscribe.css";

function Subscribe({ language }) {
  const [email, setEmail] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [companies, setCompanies] = useState([]);

  // Fetch company data using the API utility function
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const response = await fetchCompaniesData();
        setCompanies(response.data?.data || []); // Handle the API response
      } catch (error) {
        console.error("Error fetching companies:", error);
      }
    };

    fetchCompanies();
  }, []);

  const handleSubscribe = async () => {
    setEmail("");
    try {
      const response = await subscribeNewsletter(email);
      if (response.status === 200) {
        setSuccessMessage(language === "en" ? "Subscribed successfully!" : "تم الاشتراك بنجاح!");
      }
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
    }
  };

  return (
    <section className="container-fluid" style={{ background: "#002752" }} dir={language === "en" ? "ltr" : "rtl"}>
      <div className="row p-5 m-3">
        <div className="col-md-6 p-3">
          <h3 className="Subscribeh3" style={{ color: "white" }}>
            {language === "en" ? (
              <>
                Subscribe to <br /> Innovation Future Newsletter
              </>
            ) : (
              "            اشترك أخبار مستقبل الابتكار"
            )}
          </h3>
          <div className="subscribe-input-container">
            <input
              type="email"
              className="form-control email-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={language === "en" ? "Enter your email" : "بريدك الالكتروني "}
            />
            <button type="button" className="btn btn-light subscribe-button" onClick={handleSubscribe}>
              {language === "en" ? "Subscribe Now" : "اشترك الآن "}
            </button>
          </div>
          {successMessage && <p style={{ color: "green" }}>{successMessage}</p>}
        </div>
        <div className="col-md-6 p-3">
          <h5 className="fs-3 Popularlink pb-4" style={{ color: "white" }}>
            {language === "en" ? "Our group of companies" : "شركاتنا "}
          </h5>
          {companies.map((company) => (
            <a
              key={company._id}
              href={company.link}
              target="_blank"
              rel="noopener noreferrer"
            >
              <button type="button" className="btn btn-outline-light btn-sm mb-3 me-3">
                {language === "en" ? company.title_en : company.title_ar}
              </button>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Subscribe;
